#!/usr/bin/env bash
set -u

echo "== 系统 =="
uname -a
dpkg --print-architecture 2>/dev/null || true
getconf GNU_LIBC_VERSION 2>/dev/null || true

echo
echo "== 安装包 =="
dpkg-query -W -f='${Status} ${Package} ${Version} ${Architecture}\n' \
    rustdesk-unattended-wayland 2>/dev/null || echo "未安装"

echo
echo "== 服务 =="
systemctl is-enabled rustdesk.service 2>&1 || true
systemctl is-active rustdesk.service 2>&1 || true
systemctl status rustdesk.service --no-pager -l 2>&1 | tail -n 35

echo
echo "== RustDesk 注册 =="
config="${HOME}/.config/rustdesk/RustDesk.toml"
if [[ -r "$config" ]]; then
    value="$(sed -n 's/^key_confirmed = //p' "$config" | tail -n 1)"
    echo "key_confirmed=${value:-unknown}"
else
    echo "尚未生成用户配置；请先打开一次 RustDesk。"
fi

echo
echo "== DNS =="
getent ahostsv4 rs-ny.rustdesk.com 2>&1 | head -n 4 || true

echo
echo "== 最近的服务端日志 =="
log="${HOME}/.local/share/logs/RustDesk/server/rustdesk_rCURRENT.log"
if [[ -r "$log" ]]; then
    tail -n 80 "$log"
else
    echo "未找到：$log"
fi

