# RustDesk 树莓派 5 Wayland 修复版

版本：`rustdesk-unattended-wayland 1.4.9-2 arm64`

此包针对树莓派 5 的 Debian 13/Trixie、labwc/wlroots Wayland 桌面制作并验证。它修复了官方界面与定制 Rust 库不匹配导致的启动崩溃，并保留以下功能：

- Wayland 交互会话通过 PipeWire/xdg-desktop-portal-wlr 捕获；
- 后台和无人值守场景可使用 DRM/KMS 捕获；
- 键盘、鼠标通过系统 RustDesk 服务和 uinput 注入；
- 已补齐官方 1.4.9 Flutter 界面要求的全部 327 个 FFI 入口。

## 支持范围

- Raspberry Pi 5（其他 ARM64 树莓派会允许安装，但未经完整验证）；
- 64 位 ARM 系统，`dpkg` 架构必须为 `arm64`；
- Debian 13/Trixie 或基于它的 64 位 Raspberry Pi OS；
- glibc 2.38 或更高；
- labwc/wlroots Wayland 桌面。

Debian 12/Bookworm 不能直接安装，因为它缺少此包要求的 `libvpx9` 等 ABI。不要使用 `dpkg --force-*` 绕过检查。

## 安装

解压后进入目录，执行：

```bash
chmod +x install.sh check-rustdesk.sh
sudo ./install.sh
```

脚本会：

1. 检查系统、ARM64 架构和 glibc；
2. 安装 PipeWire、WirePlumber 和 wlroots 桌面门户；
3. 安装本目录中的修复版 `.deb`；
4. 启用并启动 `rustdesk.service`；
5. 验证版本、服务状态和动态库依赖。

安装完成后建议注销并重新登录桌面，或重启一次：

```bash
sudo reboot
```

然后从应用菜单打开 RustDesk。首次注册通常需要几秒到半分钟。

## 无法连接 / 显示 Not ready

先运行：

```bash
./check-rustdesk.sh
```

确认输出中：

- 服务为 `enabled` 和 `active`；
- `key_confirmed=true`。

RustDesk 官方协调服务需要 UDP 21116。如果设备使用 Clash Verge/Mihomo，并且当前节点是 HTTP 类型或显示 `udp: false`，全局代理会导致注册失败，典型日志为：

```text
[UDP] ... rs-ny.rustdesk.com:21116 error: no support
```

推荐保留原代理节点，同时使用 Clash 规则模式，并把下面规则放在最前面：

```yaml
- DOMAIN-SUFFIX,rustdesk.com,DIRECT
```

或者换成明确支持 UDP 的节点。修改后等待约 30 秒，再检查 `key_confirmed`。

常用出站端口：TCP/UDP `21115-21119`。局域网或单位网络若有出口防火墙，需要允许这些出站连接。

## Wayland 提示

RustDesk 左侧显示 “Wayland support is experimental” 是上游界面的通用提示，不代表此定制后端未启用。

如果交互式共享弹出屏幕选择窗口，请允许 `xdg-desktop-portal-wlr` 共享目标显示器。无人值守功能依赖系统级 RustDesk 服务；不要禁用该服务。

## 查看日志

用户服务端日志：

```bash
tail -n 100 ~/.local/share/logs/RustDesk/server/rustdesk_rCURRENT.log
```

系统服务日志：

```bash
journalctl -u rustdesk.service -n 100 --no-pager
```

## 卸载

```bash
sudo apt remove rustdesk-unattended-wayland
```

## 安全说明

此构建支持系统服务、uinput 和无人值守 DRM/KMS 捕获，权限高于普通桌面应用。只应安装在你拥有或获准管理的设备上，并设置强密码。不要公开截图中的设备密码。

