#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_NAME="rustdesk-unattended-wayland"
PACKAGE_VERSION="1.4.9-2"
DEB_NAME="rustdesk-unattended-wayland-1.4.9-2-aarch64.deb"
DEB_SHA256="26a03b6bdf6af2f039362cd55c8fab7e5a9e774a2d17cd3a1ec83cb2743164b6"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DEB_PATH="$SCRIPT_DIR/$DEB_NAME"

die() {
    echo "错误：$*" >&2
    exit 1
}

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    command -v sudo >/dev/null 2>&1 || die "请使用 root 账户运行，或先安装 sudo。"
    exec sudo -- "$0" "$@"
fi

command -v dpkg >/dev/null 2>&1 || die "未找到 dpkg；此安装包仅支持 Debian/Raspberry Pi OS。"
command -v apt-get >/dev/null 2>&1 || die "未找到 apt-get。"
[[ -f "$DEB_PATH" ]] || die "缺少安装包：$DEB_NAME"
actual_sha256="$(sha256sum "$DEB_PATH" | awk '{print $1}')"
[[ "$actual_sha256" == "$DEB_SHA256" ]] || die "安装包校验失败，请重新复制或解压本安装包。"

arch="$(dpkg --print-architecture)"
[[ "$arch" == "arm64" ]] || die "需要 64 位 ARM 系统（arm64），当前为：$arch"

if [[ -r /etc/os-release ]]; then
    # shellcheck disable=SC1091
    source /etc/os-release
    case "${ID:-}" in
        debian|raspbian) ;;
        *) die "仅支持 Debian/Raspberry Pi OS，当前系统为：${PRETTY_NAME:-unknown}" ;;
    esac
    [[ "${VERSION_CODENAME:-}" == "trixie" ]] || \
        die "需要 Debian 13/Trixie，当前版本为：${PRETTY_NAME:-unknown}"
fi

glibc_version="$(getconf GNU_LIBC_VERSION 2>/dev/null | awk '{print $2}')"
[[ -n "$glibc_version" ]] || die "无法检测 glibc 版本。"
dpkg --compare-versions "$glibc_version" ge 2.38 || \
    die "需要 glibc >= 2.38，当前为：$glibc_version"

if [[ -r /proc/device-tree/model ]]; then
    model="$(tr -d '\0' </proc/device-tree/model)"
    echo "检测到设备：$model"
    if [[ "$model" != *"Raspberry Pi 5"* ]]; then
        echo "警告：此构建仅在 Raspberry Pi 5 上完整验证；当前设备将继续安装。" >&2
    fi
fi

echo "正在更新软件索引……"
apt-get update

echo "正在安装 Wayland、PipeWire 和桌面门户依赖……"
apt-get install -y \
    pipewire \
    wireplumber \
    xdg-desktop-portal \
    xdg-desktop-portal-wlr

echo "正在安装 RustDesk Wayland 修复版 $PACKAGE_VERSION……"
apt-get install -y "$DEB_PATH"

systemctl daemon-reload
systemctl enable --now rustdesk.service

installed_version="$(dpkg-query -W -f='${Version}' "$PACKAGE_NAME")"
[[ "$installed_version" == "$PACKAGE_VERSION" ]] || \
    die "版本验证失败：期望 $PACKAGE_VERSION，实际 $installed_version"
systemctl is-active --quiet rustdesk.service || \
    die "RustDesk 服务未能启动，请运行：journalctl -u rustdesk.service -n 100"

if ldd /usr/share/rustdesk/lib/librustdesk.so 2>/dev/null | grep -q 'not found'; then
    ldd /usr/share/rustdesk/lib/librustdesk.so | grep 'not found' >&2
    die "仍有动态库依赖缺失。"
fi

echo
echo "安装完成：$PACKAGE_NAME $installed_version"
echo "服务状态：active / enabled"
echo "请注销并重新登录 Wayland 桌面（或重启），然后从应用菜单打开 RustDesk。"
echo "如界面显示 Not ready，请参阅 README.md 的“无法连接”章节。"
